import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class WeatherHomePage extends StatefulWidget {
  @override
  _WeatherHomePageState createState() => _WeatherHomePageState();
}

class _WeatherHomePageState extends State<WeatherHomePage> {
  String city = 'London'; // Default city
  Map<String, dynamic>? weatherData;
  final String apiKey = '3addeadaa5db9f256b8510a58e9e0734'; // Your OpenWeatherMap API key

  // Fetch weather data
  Future<void> fetchWeather() async {
    final response = await http.get(
      Uri.parse('https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric'),
    );
    if (response.statusCode == 200) {
      setState(() {
        weatherData = json.decode(response.body);
      });
    } else {
      throw Exception('Failed to load weather data');
    }
  }

  @override
  void initState() {
    super.initState();
    fetchWeather(); // Fetch weather data on app load for the default city
  }

  // Build the weather UI
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Weather App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Enter City',
                border: OutlineInputBorder(),
              ),
              onSubmitted: (value) {
                setState(() {
                  city = value;
                  fetchWeather(); // Fetch weather for the entered city
                });
              },
            ),
            SizedBox(height: 20),
            if (weatherData != null)
              Column(
                children: [
                  Text(
                    '${weatherData!['name']}',
                    style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    '${weatherData!['main']['temp']} °C',
                    style: TextStyle(fontSize: 24),
                  ),
                  Text('Condition: ${weatherData!['weather'][0]['description']}'),
                  Image.network(
                    'https://openweathermap.org/img/wn/${weatherData!['weather'][0]['icon']}@2x.png',
                  ),
                ],
              )
            else
              CircularProgressIndicator(), // Show a loading indicator while data is being fetched
          ],
        ),
      ),
    );
  }
}
