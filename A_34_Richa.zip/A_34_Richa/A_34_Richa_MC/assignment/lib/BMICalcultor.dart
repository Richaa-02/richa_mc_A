import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


class BMICalculator extends StatefulWidget {
  const BMICalculator({super.key});

  @override
  State<BMICalculator> createState() => _BMICalcultorState();
}

class _BMICalcultorState extends State<BMICalculator> {
 final TextEditingController age = TextEditingController();
 final TextEditingController height = TextEditingController();
 final TextEditingController weight = TextEditingController();
 final TextEditingController bmi  = TextEditingController();

 double _bmi= 0.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'BMI Calculator',
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 30,
              ),
              Text(
                "Enter Height, Inches & Feet",style: TextStyle(
                color: Colors.red,
                fontSize: 25,
              ),
              ),
              SizedBox(
                height: 30,
              ),
              Padding(padding: EdgeInsets.all(30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Text("Enter Height Value"
                  //   ,
                  //     style: TextStyle(
                  //       color: Colors.black,
                  //       fontSize: 12,
                  //     ),
                  // ),
                  TextFormField(
                    controller:  age,
                    decoration: new InputDecoration(
                        labelText: "Enter Age",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                        )
                    ),
                    keyboardType: TextInputType.number,
                    inputFormatters: <TextInputFormatter>[
                      FilteringTextInputFormatter.digitsOnly,
                      ],
                    ),
                  SizedBox(
                    height: 30,
                  ),
                  TextFormField(
                    controller: height,
                      decoration: new InputDecoration(
                          labelText: "Enter Height",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                          )
                      ),
                      keyboardType: TextInputType.number,
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]+[,.]{0,1}[0-9]*')
                        )
                      ],
                    ),
                  SizedBox(
                    height: 30,
                  ),
                  TextFormField(
                    controller: weight,
                    decoration: new InputDecoration(
                        labelText: "Enter Weight",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                        )
                    ),
                    keyboardType: TextInputType.number,
                    inputFormatters: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9]+[,.]{0,1}[0-9]*')
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  SizedBox(
                    height: 50,
                    width: 100000,
                  child : ElevatedButton(
                    onPressed: () {
                      print("Submit");
                      // if(int.parse(age.text.isEmpty)){
                      //   print("Please Enter Number");
                      // }else if(height.text.isEmpty && double.parse(height as String)<=0){
                      //   print("Please Enter Height");
                      // }
                      if(age.text.isEmpty || height.text.isEmpty || weight.text.isEmpty){
                        FlutterToast.showToast(msg:"Please Enter All fields");
                      }else{
                        double heightInMeters = double.parse(height.text) / 100;
                        _bmi = double.parse(weight.text) / (heightInMeters * heightInMeters);
                        setState(() {});
                      }
                    },
                    child: Text(
                      'Calculate',
                      style: TextStyle(
                        color: Colors.red,
                      ),
                    ),
                  ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Center(
                    child: Text(
                      'Your BMI is :${_bmi.toStringAsFixed(2)}',
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                      ),
                    ),
                  )
                  ],
                  )
                ,),
            ],
          ),
        )
      ),
    );
  }
}

class FlutterToast {
  static void showToast({required String msg}) {}
}
