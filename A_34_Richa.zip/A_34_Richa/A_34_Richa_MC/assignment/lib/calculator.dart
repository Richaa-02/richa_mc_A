// import 'package:assignment/calculator/Calcultor_App.dart';
import 'package:assignment/weather_home_page.dart';
import 'package:flutter/material.dart';

import 'BMICalcultor.dart';
import 'calculator/CalculatorApp.dart';
import 'meals_home_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Page',style: TextStyle(
          ),
        ),
          actions: [
      PopupMenuButton(
          itemBuilder: (BuildContext context) => [
            PopupMenuItem<String>(
            value: '1',
            child: Text('BMI Calculator'),
          ),
            PopupMenuItem<String>(
            value: '2',
            child: Text('Calculator App'),
          ),
            PopupMenuItem<String>(
              value: '3',
              child: Text('Assignment 3'),
            ),
            PopupMenuItem<String>(
              value: '4',
              child: Text('Assignment 4'),
            ),
        ],
        onSelected:(String menu) {
          if(menu == '1'){
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => BMICalculator()),
            );
          }else if(menu == '2'){
            Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CalculatorApp())
            );
          }
            else if(menu == '3'){
            Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => WeatherHomePage())
            );
            }
            else if(menu == '2') {
            Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MealsHomePage())
            );
          }
        },
      ),
    ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Assignment App",style: TextStyle(
              color: Colors.black,
            )
            ),
            SizedBox(
              height: 30,
            ),
            ElevatedButton(
              child: Text("BMI Calculator"),
              onPressed: (){
                print("Button Pressed");
              },
            )
          ],
        ),
      ),
    );
  }
}
